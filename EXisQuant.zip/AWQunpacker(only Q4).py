import numpy as np
import time
import struct
import shutil
import os
from gguf import GGUFReader

DECODE_MAP = {"00": 7, "01": 8, "100": 6, "101": 9, "1100": 5, "1101": 10, "11100": 4, "11101": 11, "111100": 3, "111101": 12, "1111100": 2, "1111101": 13, "11111100": 1, "11111101": 14, "111111100": 0, "111111101": 15}

def decompress(compressed_bytes, original_length):
    bit_string = "".join(f"{b:08b}" for b in compressed_bytes)
    decompressed_weights = []
    current_code = ""
    
    for bit in bit_string:
        current_code += bit
        if current_code in DECODE_MAP:
            decompressed_weights.append(DECODE_MAP[current_code])
            current_code = ""
            if len(decompressed_weights) == original_length:
                break
    return decompressed_weights

def pack_q4_0_fast(weights, scales):
    num_blocks = len(scales) // 2
    w_arr = np.asarray(weights, dtype=np.uint8)
    
    low = w_arr[0::2]
    high = w_arr[1::2]
    packed_qs = (high << 4) | low
    
    packed_qs_2d = packed_qs.reshape(num_blocks, 16)
    scales_2d = np.frombuffer(scales, dtype=np.uint8).reshape(num_blocks, 2)
    
    repacked_blocks = np.hstack((scales_2d, packed_qs_2d))
    return repacked_blocks.tobytes()

if __name__ == "__main__":
    compressed_model_path = "C:\EXisQuant\qwen2.5-0.5b-instruct-q4_0.exiq"
    original_gguf_path = "C:\EXisQuant\qwen2.5-0.5b-instruct-q4_0.gguf"
    output_gguf_path = "C:\EXisQuant\qwen2.5-0.5b-instruct-q4_0AWQ.gguf"
    
    print("="*60)
    print("        EXisQuant - AWQ DECOMPRESSOR v1.0")
    print("="*60)
    
    print("подготовка GGUF-копии...")
    shutil.copyfile(original_gguf_path, output_gguf_path)
    
    reader = GGUFReader(original_gguf_path)
    gguf_tensors = {t.name: t for t in reader.tensors}
    
    print("2. Распаковка AWQ-файла...")
    start_time = time.time()
    
    with open(compressed_model_path, "rb") as in_f:
        num_tensors = struct.unpack("<I", in_f.read(4))[0]
        is_important_col = np.frombuffer(in_f.read(896), dtype=bool)
        
        for i in range(num_tensors):
            name_len = struct.unpack("<B", in_f.read(1))[0]
            name = struct.unpack(f"<{name_len}s", in_f.read(name_len))[0].decode('utf-8')
            is_compressed, orig_len, scales_len, data_len = struct.unpack("<BIII", in_f.read(13))
            
            if is_compressed == 1:
                scales_data = in_f.read(scales_len)
                compressed_data = in_f.read(data_len)
            
                decoded_values = decompress(compressed_data, orig_len)
            
                rows = orig_len // 896
                w_matrix = np.array(decoded_values, dtype=np.uint8).reshape(rows, 896)
                
                unimportant_mask = ~is_important_col
                w_matrix[:, unimportant_mask] = (w_matrix[:, unimportant_mask] - 4) * 2
                
                
                repacked_data = pack_q4_0_fast(w_matrix.flatten(), scales_data)
            else:
                repacked_data = in_f.read(data_len)
                
            
            if name in gguf_tensors:
                target_tensor = gguf_tensors[name]
                with open(output_gguf_path, "r+b") as out_f:
                    out_f.seek(target_tensor.data_offset)
                    out_f.write(repacked_data)
                print(f"   Восстановлен слой: {name}")
                
    print("\n" + "="*60)
    print("  ГОТОВО")
    print("="*60)
    print(f"   Создан рабочий файл: {output_gguf_path}")
    print("============================================================")