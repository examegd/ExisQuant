import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"

import numpy as np
import time
import struct
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from gguf import GGUFReader


ENCODE_MAP = {
    7: "00",     8: "01",
    6: "100",    9: "101",
    5: "1100",   10: "1101",
    4: "11100",  11: "11101",
    3: "111100", 12: "111101",
    2: "1111100", 13: "1111101",
    1: "11111100", 14: "11111101",
    0: "111111100", 15: "111111101"
}

captured_activations = []

def activation_hook(module, input_args, output):
    x = input_args[0].detach().cpu()
    x_flat = x.view(-1, x.size(-1))
    captured_activations.append(x_flat)

def unpack_q4_0_fast(tensor_data):
    tensor_data = np.asarray(tensor_data, dtype=np.uint8).flatten()
    num_blocks = len(tensor_data) // 18
    blocks = tensor_data.reshape(num_blocks, 18)
    scales = blocks[:, 0:2].tobytes()
    qs = blocks[:, 2:18]
    
    low_nibbles = qs & 0x0F
    high_nibbles = (qs >> 4) & 0x0F
    combined = np.stack((low_nibbles, high_nibbles), axis=-1)
    return combined.flatten(), scales

def compress(weights):
    bit_string_list = [ENCODE_MAP[w] for w in weights]
    all_bits = "".join(bit_string_list)
    
    padding = (8 - len(all_bits) % 8) % 8
    all_bits += "0" * padding
    
    byte_chunks = [all_bits[i:i+8] for i in range(0, len(all_bits), 8)]
    compressed_bytes = bytearray(int(chunk, 2) for chunk in byte_chunks)
    return compressed_bytes

if __name__ == "__main__":
    print("="*60)
    print("        EXisQuant - AWQ COMPILER v1.0")
    print("="*60)
    
    model_raw_path = r"C:\EXisQuant\qwen_raw"
    model_gguf_path = "C:\EXisQuant\qwen2.5-0.5b-instruct-q4_0.gguf"
    output_path = "C:\EXisQuant\qwen2.5-0.5b-instruct-q4_0.exiq"
    
    
    print("запуск калибровки модели для построения iMatrix...")
    tokenizer = AutoTokenizer.from_pretrained(model_raw_path)
    model = AutoModelForCausalLM.from_pretrained(model_raw_path, torch_dtype=torch.float32)
    
    target_layer = model.model.layers[0].self_attn.q_proj
    hook = target_layer.register_forward_hook(activation_hook)
    
    prompt = "Привет! Расскажи мне интересную историю"
    inputs = tokenizer(prompt, return_tensors="pt")
    with torch.no_grad():
        outputs = model.generate(**inputs, max_new_tokens=20, do_sample=False)
    hook.remove()
    
    
    all_x = torch.cat(captured_activations, dim=0)
    importance_vector = torch.mean(all_x ** 2, dim=0).numpy()
    
    num_important = int(896 * 0.30)
    important_cols = np.argsort(importance_vector)[-num_important:]
    
    is_important_col = np.zeros(896, dtype=bool)
    is_important_col[important_cols] = True
    
    print(f"   iMatrix успешно построен. Защищено столбцов: {num_important}")
    
    del model
    torch.cuda.empty_cache()
    
    print("\n открытие оригинальной GGUF-модели...")
    reader = GGUFReader(model_gguf_path)
    num_tensors = len(reader.tensors)
    
    with open(output_path, "wb") as out_f:
        
        out_f.write(struct.pack("<I", num_tensors))
     
        out_f.write(is_important_col.tobytes())
        
        compressed_count = 0
        copied_count = 0
        
        print("\n начало AWQ-сжатия слоев внимания...")
        for idx, tensor in enumerate(reader.tensors):
            name_bytes = tensor.name.encode('utf-8')
            name_len = len(name_bytes)
            
            
            is_attn_layer = (tensor.tensor_type.name == "Q4_0") and ("blk." in tensor.name) and \
                             ("attn_q" in tensor.name or "attn_k" in tensor.name or "attn_v" in tensor.name)
            
            if is_attn_layer:
                raw_weights, scales_data = unpack_q4_0_fast(tensor.data)
                
                rows = len(raw_weights) // 896
                w_matrix = np.array(raw_weights, dtype=np.int16).reshape(rows, 896)
                
                processed_matrix = np.copy(w_matrix)
                
                unimportant_mask = ~is_important_col
                processed_matrix[:, unimportant_mask] = np.clip(w_matrix[:, unimportant_mask] // 2, 0, 7) + 4
                
                flat_weights = processed_matrix.flatten().tolist()
                compressed_data = compress(flat_weights)
                
                is_compressed = 1
                orig_len = len(flat_weights)
                scales_len = len(scales_data)
                data_len = len(compressed_data)
                
                out_f.write(struct.pack(f"<B{name_len}sBIII", name_len, name_bytes, is_compressed, orig_len, scales_len, data_len))
                out_f.write(scales_data)
                out_f.write(compressed_data)
                
                raw_weights_size = orig_len // 2
                layer_saving = (1 - (data_len / raw_weights_size)) * 100
                print(f"   [{idx+1:02d}] AWQ Сжат: {tensor.name:<35} | Экономия: {layer_saving:5.2f}%")
                compressed_count += 1
            else:
                
                is_compressed = 0
                orig_len = 0
                scales_len = 0
                data_bytes = tensor.data.tobytes()
                data_len = len(data_bytes)
                
                out_f.write(struct.pack(f"<B{name_len}sBIII", name_len, name_bytes, is_compressed, orig_len, scales_len, data_len))
                out_f.write(data_bytes)
                copied_count += 1
                
    
    original_size = os.path.getsize(model_gguf_path)
    compressed_size = os.path.getsize(output_path)
    total_saving = original_size - compressed_size
    print("\n" + "="*60)
    print("   ИТОГИ СЖАТИЯ AWQ:")
    print("="*60)
    print(f"   Исходный размер (.GGUF):  {original_size / 1024 / 1024:.2f} МБ")
    print(f"   Сжатый размер (.EXIQ):    {compressed_size / 1024 / 1024:.2f} МБ")
    print(f"   Чистая экономия памяти:   {total_saving / 1024 / 1024:.2f} МБ ({ (total_saving / original_size) * 100:.2f}%)")
    print("="*60)