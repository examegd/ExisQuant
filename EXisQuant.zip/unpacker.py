import numpy as np
import time
import struct
import shutil
import os
import tkinter as tk
from tkinter import filedialog
from gguf import GGUFReader

def pack_q4_0_fast(weights, scales):
    num_blocks = len(scales) // 2
    w_arr = np.asarray(weights, dtype=np.uint8)
    
    low = w_arr[0::2]
    high = w_arr[1::2]
    packed_qs = (high << 4) | low
    
    packed_qs_2d = packed_qs.reshape(num_blocks, 16)
    scales_2d = np.frombuffer(scales, dtype=np.uint8).reshape(num_blocks, 2)
    
    repacked_blocks = np.hstack((scales_2d, packed_qs_2d))
    return repacked_blocks.tobytes()

if __name__ == "__main__":
    # hide the main tkinter window
    root = tk.Tk()
    root.withdraw()

    print("=" * 60)
    print("        exisquant - vector decompressor")
    print("=" * 60)

    # prompt user for input files
    compressed_model_path = filedialog.askopenfilename(
        title="select compressed exiq model",
        filetypes=[("exiq compressed models", "*.exiq"), ("all files", "*.*")]
    )
    if not compressed_model_path:
        print("error: no compressed file selected.")
        exit(1)

    original_gguf_path = filedialog.askopenfilename(
        title="select original template gguf model",
        filetypes=[("gguf models", "*.gguf"), ("all files", "*.*")]
    )
    if not original_gguf_path:
        print("error: no template file selected.")
        exit(1)

    output_gguf_path = filedialog.asksaveasfilename(
        title="save restored gguf model as",
        defaultextension=".gguf",
        filetypes=[("gguf models", "*.gguf"), ("all files", "*.*")]
    )
    if not output_gguf_path:
        print("error: no output destination selected.")
        exit(1)
    
    print("1. preparing gguf copy...")
    try:
        shutil.copyfile(original_gguf_path, output_gguf_path)
    except Exception as e:
        print(f"error copying file: {e}")
        exit(1)
    
    reader = GGUFReader(original_gguf_path)
    gguf_tensors = {t.name: t for t in reader.tensors}
    
    print("2. decompressing vector file...")
    start_time = time.time()
    
    with open(compressed_model_path, "rb") as in_f:
        num_tensors = struct.unpack("<I", in_f.read(4))[0]
        
        for idx in range(num_tensors):
            name_len = struct.unpack("<B", in_f.read(1))[0]
            name = struct.unpack(f"<{name_len}s", in_f.read(name_len))[0].decode('utf-8')
            is_compressed, orig_len, scales_len, data_len = struct.unpack("<BIII", in_f.read(13))
            
            if is_compressed == 2:
                scales_data = in_f.read(scales_len)
                codebook_bytes = in_f.read(4096)
                codebook = np.frombuffer(codebook_bytes, dtype=np.float32).reshape(256, 4)
                indices_bytes = in_f.read(data_len)
                compressed_indices = np.frombuffer(indices_bytes, dtype=np.uint8)
                
                decoded_vectors = codebook[compressed_indices]
                restored_weights = np.clip(np.round(decoded_vectors.flatten()), 0, 15).astype(np.uint8)
                repacked_data = pack_q4_0_fast(restored_weights, scales_data)
            else:
                repacked_data = in_f.read(data_len)
                
            if name in gguf_tensors:
                target_tensor = gguf_tensors[name]
                with open(output_gguf_path, "r+b") as out_f:
                    out_f.seek(target_tensor.data_offset)
                    out_f.write(repacked_data)
                print(f"   [{idx+1:03d}/{num_tensors}] restored layer: {name}")
                
    print("\n" + "=" * 60)
    print("   vector model decompression completed!")
    print("=" * 60)
    print(f"   elapsed time:      {time.time() - start_time:.2f} s")
    print(f"   restored file:     {output_gguf_path}")
    print("=" * 60)