import numpy as np
import time
import struct
import os
import tkinter as tk
from tkinter import filedialog
from gguf import GGUFReader

def unpack_q4_0_fast(tensor_data):
    tensor_data = np.asarray(tensor_data, dtype=np.uint8).flatten()
    num_blocks = len(tensor_data) // 18
    
    blocks = tensor_data.reshape(num_blocks, 18)
    scales = blocks[:, 0:2].tobytes()
    qs = blocks[:, 2:18]
    
    low_nibbles = qs & 0x0F
    high_nibbles = (qs >> 4) & 0x0F
    
    combined = np.stack((low_nibbles, high_nibbles), axis=-1)
    raw_weights = combined.flatten()
    
    return raw_weights, scales

def train_kmeans_fast(data, k=256, max_iters=8):
    centroids = data[np.random.choice(data.shape[0], k, replace=False)].astype(np.float32)
    
    for _ in range(max_iters):
        chunk_size = 2000
        labels = []
        for i in range(0, len(data), chunk_size):
            chunk = data[i:i+chunk_size]
            diffs = chunk[:, np.newaxis, :] - centroids[np.newaxis, :, :]
            dists = np.sum(diffs ** 2, axis=2)
            labels.extend(np.argmin(dists, axis=1))
            
        labels = np.array(labels)
        
        new_centroids = np.zeros_like(centroids)
        for i in range(k):
            points_in_cluster = data[labels == i]
            if len(points_in_cluster) > 0:
                new_centroids[i] = points_in_cluster.mean(axis=0)
            else:
                new_centroids[i] = centroids[i]
                
        if np.allclose(centroids, new_centroids, atol=1e-2):
            break
        centroids = new_centroids
        
    return centroids

def encode_vectors(vectors, centroids):
    chunk_size = 5000
    labels = []
    for i in range(0, len(vectors), chunk_size):
        chunk = vectors[i:i+chunk_size]
        diffs = chunk[:, np.newaxis, :] - centroids[np.newaxis, :, :]
        dists = np.sum(diffs ** 2, axis=2)
        labels.extend(np.argmin(dists, axis=1))
    return np.array(labels, dtype=np.uint8)

if __name__ == "__main__":
    # hide the main tkinter window
    root = tk.Tk()
    root.withdraw()
    
    print("=" * 60)
    print("        exisquant - vector quantization packer")
    print("=" * 60)
    
    # prompt user for input files
    model_path = filedialog.askopenfilename(
        title="select original gguf model",
        filetypes=[("gguf models", "*.gguf"), ("all files", "*.*")]
    )
    if not model_path:
        print("error: no input file selected.")
        exit(1)
        
    output_path = filedialog.asksaveasfilename(
        title="save compressed exiq model as",
        defaultextension=".exiq",
        filetypes=[("exiq compressed models", "*.exiq"), ("all files", "*.*")]
    )
    if not output_path:
        print("error: no output file selected.")
        exit(1)
        
    print(f"1. reading original model: {model_path}...")
    try:
        reader = GGUFReader(model_path)
    except Exception as e:
        print(f"error reading file: {e}")
        exit(1)
        
    num_tensors = len(reader.tensors)
    start_total_time = time.time()
    
    with open(output_path, "wb") as out_f:
        out_f.write(struct.pack("<I", num_tensors))
        
        compressed_count = 0
        copied_count = 0
        
        print("\n2. starting vector compression on block layers (attention + mlp)...")
        for idx, tensor in enumerate(reader.tensors):
            name_bytes = tensor.name.encode('utf-8')
            name_len = len(name_bytes)
            
            should_compress = (tensor.tensor_type.name == "Q4_0") and ("blk." in tensor.name)
            
            if should_compress:
                raw_weights, scales_data = unpack_q4_0_fast(tensor.data)
                vectors = np.array(raw_weights, dtype=np.float32).reshape(-1, 4)
                
                np.random.seed(42)
                sample_size = min(len(vectors), 4000)
                train_sample = vectors[np.random.choice(len(vectors), sample_size, replace=False)]
                
                codebook = train_kmeans_fast(train_sample, k=256)
                compressed_indices = encode_vectors(vectors, codebook)
                
                is_compressed = 2 
                orig_len = len(raw_weights)
                scales_len = len(scales_data)
                
                codebook_bytes = codebook.tobytes()
                indices_bytes = compressed_indices.tobytes()
                data_len = len(indices_bytes)
                
                out_f.write(struct.pack(f"<B{name_len}sBIII", name_len, name_bytes, is_compressed, orig_len, scales_len, data_len))
                out_f.write(scales_data)
                out_f.write(codebook_bytes) 
                out_f.write(indices_bytes)  
                
                raw_size = orig_len // 2
                layer_saving = (1 - ((data_len + len(codebook_bytes)) / raw_size)) * 100
                print(f"   [{idx+1:03d}/{num_tensors}] vq compressed: {tensor.name:<35} | saving: {layer_saving:5.2f}%")
                compressed_count += 1
                
            else:
                is_compressed = 0
                orig_len = 0
                scales_len = 0
                data_bytes = tensor.data.tobytes()
                data_len = len(data_bytes)
                
                out_f.write(struct.pack(f"<B{name_len}sBIII", name_len, name_bytes, is_compressed, orig_len, scales_len, data_len))
                out_f.write(data_bytes)
                copied_count += 1
                
    total_time = time.time() - start_total_time
    original_size = os.path.getsize(model_path)
    compressed_size = os.path.getsize(output_path)
    total_saving = original_size - compressed_size
    
    print("\n" + "=" * 60)
    print("   vector compression finished:")
    print("=" * 60)
    print(f"   vq compressed layers:     {compressed_count}")
    print(f"   copied unchanged layers:  {copied_count}")
    print(f"   elapsed time:             {total_time:.2f} s")
    print(f"   original gguf size:       {original_size / 1024 / 1024:.2f} mb")
    print(f"   compressed exiq size:     {compressed_size / 1024 / 1024:.2f} mb")
    print(f"   --> saved space on disk:  {total_saving / 1024 / 1024:.2f} mb ({ (total_saving / original_size) * 100:.2f}%)")
    print("=" * 60)